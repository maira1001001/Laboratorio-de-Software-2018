package testing;

public class TestDeprecated {

	@Deprecated
	public void hacer() {
		System.out.println("Testeando: Deprecated");
	}
	
}
