package testing;

public class TestSobreescritura {
	
	@Override
	public String toString() {
		return super.toString() + " Testeando: 'Override";
	}
}
