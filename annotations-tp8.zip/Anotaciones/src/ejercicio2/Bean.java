package ejercicio2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

/*
La salida en el archivo AchivoMapeado.txt ser�a:
<nombreClase>Mapeado</nombreClase>
<nombreAtributo>valor</nombreAtributo>
<nombreValor>Default1</nombrenombreValor>
<nombreAtributo>valor2</nombreAtributo>
<nombreValor>20</nombrenombreValor>
<nombreAtributo>valor3</nombreAtributo>
<nombreValor>30.2</nombrenombreValor>
 */

@Archivo(nombre = "AchivoMapeado.txt")
public class Bean {

	@AlmacenarAtributo
	private String valor = "Default1";

	@AlmacenarAtributo
	private Integer valor2 = 20;

	@AlmacenarAtributo
	private Float valor3 = 30.20f;

	private Float valor4 = 30.20f;

	public static void main(String[] args) throws Exception {
		Archivo archivo = Bean.class.getAnnotation(Archivo.class);
		String fileName = archivo.nombre();
		
//		Annotation[] mapeadoAnnotations = Bean.class.getAnnotations();
//		
//		for (Annotation annotation : mapeadoAnnotations) {
//			System.out.println("anotaciones cantidad: " + mapeadoAnnotations.length);
//			if (annotation instanceof Archivo) {
//				Archivo archivoAnnotation = (Archivo) annotation;
//				System.out.println("nombre: " + archivoAnnotation.nombre());
//				fileName = archivoAnnotation.nombre();
//			}
//		}

		FileWriter fileWriter = null;
		BufferedWriter bufWriter = null;

		try {
			fileWriter = new FileWriter(new File(fileName));
			bufWriter = new BufferedWriter(fileWriter);

			// Si no se explicita un nombre se utiliza el nombre de la clase.
			if (fileName.isEmpty()) {
				fileName = "Mapping";
			}
			
			bufWriter.write("<nombreClase>" + fileName + "</nombreClase>");
			bufWriter.newLine();

			Bean mapeado = new Bean();
			for (Field field : mapeado.getClass().getDeclaredFields()) {
				Annotation[] fieldAnnotations = field.getAnnotations();
				if (field.isAnnotationPresent(AlmacenarAtributo.class)) {
					System.out.println(field.getName());
					System.out.println(field.get(mapeado).toString());
					for (Annotation annotation : fieldAnnotations) {
						System.out.println(annotation);
						bufWriter.write("<nombreAtributo>" + field.getName() + "</nombreAtributo>");
						bufWriter.newLine();
						bufWriter.write("<nombreValor>" + field.get(mapeado).toString() + "</nombreValor>");
						bufWriter.newLine();
					}
				}
			}
			bufWriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fileWriter.close();
				bufWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
