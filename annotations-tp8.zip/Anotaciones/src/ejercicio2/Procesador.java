package ejercicio2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.Hashtable;

public class Procesador {
	
	public static void mapearYAlmacenarBeanAlFileSystem(Class bean) {
		//obtener nombre de archivo de la clase
		//obtener atributo|valor de aquellos que tienen anotaciones
		//crear el archivo
		//almacenarlo con la estructura del xml
		File fileName = getFileNameFromBeanClass(bean);
		Hashtable<String, String> dataAttributes = getAttributesToBeStoredFromBean();
		String[] xmlContent = generateXMLContent(fileName.getName(), dataAttributes);
		BufferedWriter bufWriter = createFileWithName_(fileName);
		writeDataToFile(bufWriter, xmlContent);
		
	}

	private static File getFileNameFromBeanClass(Class<?> bean) {
		Archivo archivo = bean.getClass().getAnnotation(Archivo.class); //ojo que si no est{a definido el nombre se muere
		String strFileName = archivo.nombre() == ""?bean.getName():archivo.nombre() ;
		return new File(strFileName);
	}
	
	private static String[] generateXMLContent(String name, Hashtable<String, String> dataAttributes) {
		return null;
		// TODO Auto-generated method stub
		
	}

	private static void writeDataToFile(BufferedWriter bufWriter, String[] xmlContent) {
		// TODO Auto-generated method stub
		
	}

	private static BufferedWriter createFileWithName_(File fileName) {
		// TODO Auto-generated method stub
		return null;
	}

	private static Hashtable<String, String> getAttributesToBeStoredFromBean() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public static void main(String[] args) throws Exception {
		
		Class<?> beanClass = Class.forName(args[0]);
		mapearYAlmacenarBeanAlFileSystem(beanClass);
		
		/*-------------------------------------------*/
		Annotation[] mapeadoAnnotations = Bean.class.getAnnotations();
		String fileName = new String();
		for (Annotation annotation : mapeadoAnnotations) {
			System.out.println("anotaciones cantidad: " + mapeadoAnnotations.length);
			if (annotation instanceof Archivo) {
				Archivo archivoAnnotation = (Archivo) annotation;
				System.out.println("nombre: " + archivoAnnotation.nombre());
				fileName = archivoAnnotation.nombre();
			}
		}

		FileWriter fileWriter = null;
		BufferedWriter bufWriter = null;

		try {
			fileWriter = new FileWriter(new File(fileName));
			bufWriter = new BufferedWriter(fileWriter);

			// Si no se explicita un nombre se utiliza el nombre de la clase.
			if (fileName.isEmpty()) {
				fileName = "Mapping";
			}
			
			bufWriter.write("<nombreClase>" + fileName + "</nombreClase>");
			bufWriter.newLine();

			Bean mapeado = new Bean();
			for (Field field : mapeado.getClass().getDeclaredFields()) {
				Annotation[] fieldAnnotations = field.getAnnotations();
				if (field.isAnnotationPresent(AlmacenarAtributo.class)) {
					System.out.println(field.getName());
					System.out.println(field.get(mapeado).toString());
					for (Annotation annotation : fieldAnnotations) {
						System.out.println(annotation);
						bufWriter.write("<nombreAtributo>" + field.getName() + "</nombreAtributo>");
						bufWriter.newLine();
						bufWriter.write("<nombreValor>" + field.get(mapeado).toString() + "</nombreValor>");
						bufWriter.newLine();
					}
				}
			}
			bufWriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fileWriter.close();
				bufWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
