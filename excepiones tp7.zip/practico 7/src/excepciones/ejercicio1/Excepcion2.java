package excepciones.ejercicio1;

class Excepcion2 extends Excepcion1{}
