package excepciones.ejercicio1;

public class Excepcion1 extends Exception {}
