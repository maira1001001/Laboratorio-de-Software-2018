package excepciones.ejercicio4;

public class EquipoIncompleto extends FutbolException{}
