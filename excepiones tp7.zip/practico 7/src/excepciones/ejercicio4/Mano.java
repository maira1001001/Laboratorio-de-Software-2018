package excepciones.ejercicio4;

public class Mano extends Falta{}
