package excepciones.ejercicio4;

public class Lluvia extends ClimaException{}
