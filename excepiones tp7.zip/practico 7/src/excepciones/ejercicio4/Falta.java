package excepciones.ejercicio4;

public class Falta  extends FutbolException{}
