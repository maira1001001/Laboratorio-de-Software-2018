package excepciones.ejercicio4;

public class ClimaException extends Exception{}
