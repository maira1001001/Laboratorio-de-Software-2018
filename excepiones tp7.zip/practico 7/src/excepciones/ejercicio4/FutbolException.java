package excepciones.ejercicio4;

public class FutbolException extends Exception {}
