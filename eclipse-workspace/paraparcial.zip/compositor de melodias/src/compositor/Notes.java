package compositor;

public enum Notes {
	A, B, C, D, E, F, G;
/*	DO("C"),
	RE("D"),
	MI("E"),
	FA("F"),
	SOL("G"),
	LA("A"),
	SI("B");

	
    private final String note;
    
    Notes(String note) {
       this.note = note;
    }
    
    public String toString() {
       return note;
    }
    */
}