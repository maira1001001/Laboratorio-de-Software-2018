package collections;

public abstract class Person {

}
