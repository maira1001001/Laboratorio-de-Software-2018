package collections;

public class StringMatching {

}
