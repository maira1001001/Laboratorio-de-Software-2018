package generic_types;

public class Perro extends Animal {

}
