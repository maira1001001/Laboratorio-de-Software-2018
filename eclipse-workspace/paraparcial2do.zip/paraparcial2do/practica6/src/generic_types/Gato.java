package generic_types;

public class Gato extends Animal {

}
