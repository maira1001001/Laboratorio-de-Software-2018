package generic_types;

public class Animal {

}
