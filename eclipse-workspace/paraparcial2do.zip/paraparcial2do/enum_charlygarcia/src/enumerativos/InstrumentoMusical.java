package enumerativos;

public interface InstrumentoMusical {
	void hacerSonar();
	String queEs();
	void afinar();
}
