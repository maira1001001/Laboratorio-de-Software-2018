package threads;

public class ThreadTest {

	/*
	 * Thread caracteristicas: 
	 * 1. controla el thread
	 * 2. comportamiento:
	 * 		a. run()
	 * 		b. 	
	 * 
	 *  3. 2 formas de uso:
	 *  	a. ThreadWithRunnable    implements Runnable
	 *  	b. ThreadExtendsOfThread extends Thread
	 */
	
}
