package extendsThread;

/*
 * run()
 * join()
 * start()
 * isAlive()
 */

public class ThreadTest extends Thread{
	
		public ThreadTest(int i) {
			super("" +i);
		}
		
		
}
