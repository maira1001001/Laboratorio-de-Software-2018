package compositor;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import org.jfugue.player.Player;

public class TestingCompositor {

	public static void main(String[] args) {
		 Player player = new Player();
		 player.play("C D E F G A B");
		
		 
	}
	
}
