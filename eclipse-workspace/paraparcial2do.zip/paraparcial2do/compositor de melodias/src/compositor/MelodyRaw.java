package compositor;

import javax.swing.JPanel;

public class MelodyRaw extends JPanel {

}
