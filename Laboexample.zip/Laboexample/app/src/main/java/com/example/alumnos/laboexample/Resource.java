package com.example.alumnos.laboexample;

import java.net.URI;

/**
 * Created by Alumnos on 07/11/2018.
 */

public class Resource {
    protected String nombre;
    protected String comentario;
    protected URI url;
    protected TypeResource type;//definir al tipo del recurso como un enumerativo

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public URI getUrl() {
        return url;
    }

    public void setUrl(URI url) {
        this.url = url;
    }

    public TypeResource getType() {
        return type;
    }

    public void setType(TypeResource type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return this.getNombre();
    }

}
