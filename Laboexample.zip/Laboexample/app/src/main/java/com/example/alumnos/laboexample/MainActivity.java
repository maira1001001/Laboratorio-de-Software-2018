package com.example.alumnos.laboexample;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    ListView listView ;
    public ArrayAdapter<String> adapter ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get ListView object from xml
        listView = (ListView) findViewById(R.id.listview);

        // Defined Array values to show in ListView
        Resource[] resources = new Resource[] {
                new Instagram(),
                new Instagram()
        };

        // Define a new Adapter
        // First parameter - Context
        // Second parameter - Layout for the row
        // Third parameter - ID of the TextView to which the data is written
        // Forth - the Array of data
        ArrayAdapter<Resource> adapter = new ArrayAdapter<Resource>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, resources);

        // Assign adapter to ListView
        listView.setAdapter(adapter);

        // ListView Item Click Listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // ListView Clicked item index
                int itemPosition     = position;
                // ListView Clicked item value
                String  itemValue    = (String) listView.getItemAtPosition(position);
                // Show Alert
                Toast.makeText(getApplicationContext(),"Position :"+itemPosition+"  ListItem : " +itemValue , Toast.LENGTH_LONG).show();
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> arg0, View v, int index, long arg3) {
                String str=listView.getItemAtPosition(index).toString();
                //String url = (Instagram)listView.getAdapter().getItem(index)

                Toast.makeText(getApplicationContext(),str , Toast.LENGTH_LONG).show();
                switch (index) {
                    case 0:  openInstagram(url);
                        break;
                    case 1:  openInstagram(url);
                        break;
                    case 2:  openInstagram(url);
                        break;
                    case 3:  openInstagram(url);
                        break;
                    default: openInstagram(url);
                        break;
                }
                return true;
            }
        });
    }

    private void openInstagram(String url) {
        Uri uri = Uri.parse(url);
        Intent likeIng = new Intent(Intent.ACTION_VIEW, uri);

        likeIng.setPackage("com.instagram.android");

        try {
            startActivity(likeIng);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.instagram.com/explore/tags/ballet/?hl=es-la")));
        }
    }

}
