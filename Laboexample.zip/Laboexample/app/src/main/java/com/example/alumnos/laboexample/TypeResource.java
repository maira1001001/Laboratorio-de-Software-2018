package com.example.alumnos.laboexample;

/**
 * Created by Alumnos on 07/11/2018.
 */

public enum TypeResource {
    AUDIO, VIDEO, IMAGEN;
}
