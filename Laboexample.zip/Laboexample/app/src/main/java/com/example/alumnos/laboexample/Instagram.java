package com.example.alumnos.laboexample;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * Created by Alumnos on 07/11/2018.
 */

public class Instagram extends Resource {

    Instagram(){
        this.nombre = "Instagram";
        this.type = TypeResource.IMAGEN;
        try {
            this.url = new URI("https://www.instagram.com/explore/tags/ballet/?hl=es-la");
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

    }
}
