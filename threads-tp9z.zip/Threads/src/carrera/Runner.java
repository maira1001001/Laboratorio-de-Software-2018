package carrera;

public class Runner implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
